/** Automatically generated file. DO NOT MODIFY */
package com.qiulong.appprocesslibrary;

public final class BuildConfig {
    public final static boolean DEBUG = true;
}